"""
StyleLane - Fashion Retail Inventory Management System
Flask Application with AWS Integration (DynamoDB, SNS, EC2)
"""

from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, Response
from functools import wraps
import boto3
from boto3.dynamodb.conditions import Key, Attr
from botocore.exceptions import ClientError
import os
from datetime import datetime
import uuid
import csv
import io

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'stylelane-secret-key-change-in-production')

# AWS Configuration
AWS_REGION = os.environ.get('AWS_REGION', 'us-east-1')

# Initialize AWS clients
dynamodb = boto3.resource('dynamodb', region_name=AWS_REGION)
sns = boto3.client('sns', region_name=AWS_REGION)

# DynamoDB Tables
USERS_TABLE = os.environ.get('USERS_TABLE', 'StyleLane_Users')
PRODUCTS_TABLE = os.environ.get('PRODUCTS_TABLE', 'StyleLane_Products')
SHIPMENTS_TABLE = os.environ.get('SHIPMENTS_TABLE', 'StyleLane_Shipments')
NOTIFICATIONS_TABLE = os.environ.get('NOTIFICATIONS_TABLE', 'StyleLane_Notifications')

# SNS Topics
LOW_STOCK_TOPIC = os.environ.get('LOW_STOCK_TOPIC', '')
SHIPMENT_TOPIC = os.environ.get('SHIPMENT_TOPIC', '')

# Low stock threshold
LOW_STOCK_THRESHOLD = 10


def get_table(table_name):
    """Get DynamoDB table resource"""
    return dynamodb.Table(table_name)


def login_required(f):
    """Decorator to require login"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in to access this page.', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function


def role_required(*roles):
    """Decorator to require specific roles"""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if 'role' not in session or session['role'] not in roles:
                flash('You do not have permission to access this page.', 'danger')
                return redirect(url_for('dashboard'))
            return f(*args, **kwargs)
        return decorated_function
    return decorator


# ==================== PUBLIC ROUTES ====================

@app.route('/')
def index():
    """Landing page"""
    return render_template('index.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    """User login"""
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        try:
            table = get_table(USERS_TABLE)
            response = table.scan(
                FilterExpression=Attr('email').eq(email) & Attr('password').eq(password)
            )
            
            if response['Items']:
                user = response['Items'][0]
                session['user_id'] = user['user_id']
                session['email'] = user['email']
                session['name'] = user['name']
                session['role'] = user['role']
                flash(f'Welcome back, {user["name"]}!', 'success')
                return redirect(url_for('dashboard'))
            else:
                flash('Invalid email or password.', 'danger')
        except ClientError as e:
            flash('Login failed. Please try again.', 'danger')
            print(f"DynamoDB Error: {e}")
    
    return render_template('login.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    """User registration"""
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        password = request.form.get('password')
        role = request.form.get('role', 'store_manager')
        
        try:
            table = get_table(USERS_TABLE)
            
            # Check if email exists
            response = table.scan(
                FilterExpression=Attr('email').eq(email)
            )
            
            if response['Items']:
                flash('Email already registered.', 'warning')
                return render_template('register.html')
            
            # Create new user
            user_id = str(uuid.uuid4())
            table.put_item(Item={
                'user_id': user_id,
                'name': name,
                'email': email,
                'password': password,
                'role': role,
                'created_at': datetime.now().isoformat(),
                'status': 'active'
            })
            
            flash('Registration successful! Please log in.', 'success')
            return redirect(url_for('login'))
            
        except ClientError as e:
            flash('Registration failed. Please try again.', 'danger')
            print(f"DynamoDB Error: {e}")
    
    return render_template('register.html')


@app.route('/logout')
def logout():
    """User logout"""
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('index'))


# ==================== DASHBOARD ROUTES ====================

@app.route('/dashboard')
@login_required
def dashboard():
    """Role-based dashboard"""
    role = session.get('role')
    
    if role == 'admin':
        return redirect(url_for('admin_dashboard'))
    elif role == 'store_manager':
        return redirect(url_for('manager_dashboard'))
    elif role == 'supplier':
        return redirect(url_for('supplier_dashboard'))
    else:
        return render_template('dashboard.html')


@app.route('/admin/dashboard')
@login_required
@role_required('admin')
def admin_dashboard():
    """Admin dashboard"""
    try:
        # Get all products
        products_table = get_table(PRODUCTS_TABLE)
        products = products_table.scan()['Items']
        
        # Get all shipments
        shipments_table = get_table(SHIPMENTS_TABLE)
        shipments = shipments_table.scan()['Items']
        
        # Get all users
        users_table = get_table(USERS_TABLE)
        users = users_table.scan()['Items']
        
        # Calculate stats
        total_products = len(products)
        low_stock_count = len([p for p in products if int(p.get('quantity', 0)) < LOW_STOCK_THRESHOLD])
        pending_shipments = len([s for s in shipments if s.get('status') == 'pending'])
        total_users = len(users)
        
        stats = {
            'total_products': total_products,
            'low_stock_count': low_stock_count,
            'pending_shipments': pending_shipments,
            'total_users': total_users
        }
        
        return render_template('admin/dashboard.html', 
                             stats=stats, 
                             products=products[:10],
                             shipments=shipments[:10],
                             users=users)
    except ClientError as e:
        flash('Error loading dashboard data.', 'danger')
        print(f"DynamoDB Error: {e}")
        return render_template('admin/dashboard.html', stats={}, products=[], shipments=[], users=[])


@app.route('/manager/dashboard')
@login_required
@role_required('store_manager')
def manager_dashboard():
    """Store Manager dashboard"""
    try:
        # Get all products
        products_table = get_table(PRODUCTS_TABLE)
        products = products_table.scan()['Items']
        
        # Get recent shipments
        shipments_table = get_table(SHIPMENTS_TABLE)
        shipments = shipments_table.scan()['Items']
        
        # Low stock products
        low_stock = [p for p in products if int(p.get('quantity', 0)) < LOW_STOCK_THRESHOLD]
        
        stats = {
            'total_products': len(products),
            'low_stock_count': len(low_stock),
            'incoming_shipments': len([s for s in shipments if s.get('status') in ['pending', 'shipped']])
        }
        
        return render_template('manager/dashboard.html',
                             stats=stats,
                             products=products,
                             low_stock=low_stock,
                             shipments=shipments[:5])
    except ClientError as e:
        flash('Error loading dashboard data.', 'danger')
        print(f"DynamoDB Error: {e}")
        return render_template('manager/dashboard.html', stats={}, products=[], low_stock=[], shipments=[])


@app.route('/supplier/dashboard')
@login_required
@role_required('supplier')
def supplier_dashboard():
    """Supplier dashboard"""
    try:
        # Get shipments for this supplier
        shipments_table = get_table(SHIPMENTS_TABLE)
        shipments = shipments_table.scan(
            FilterExpression=Attr('supplier_id').eq(session['user_id'])
        )['Items']
        
        # Get restock requests (pending shipments)
        pending_requests = [s for s in shipments if s.get('status') == 'pending']
        active_shipments = [s for s in shipments if s.get('status') == 'shipped']
        completed_shipments = [s for s in shipments if s.get('status') == 'delivered']
        
        stats = {
            'pending_requests': len(pending_requests),
            'active_shipments': len(active_shipments),
            'completed_shipments': len(completed_shipments)
        }
        
        return render_template('supplier/dashboard.html',
                             stats=stats,
                             pending_requests=pending_requests,
                             active_shipments=active_shipments,
                             shipments=shipments)
    except ClientError as e:
        flash('Error loading dashboard data.', 'danger')
        print(f"DynamoDB Error: {e}")
        return render_template('supplier/dashboard.html', stats={}, pending_requests=[], active_shipments=[], shipments=[])


# ==================== PRODUCT ROUTES ====================

@app.route('/products')
@login_required
def products():
    """View all products"""
    try:
        table = get_table(PRODUCTS_TABLE)
        products = table.scan()['Items']
        return render_template('products/list.html', products=products)
    except ClientError as e:
        flash('Error loading products.', 'danger')
        return render_template('products/list.html', products=[])


@app.route('/products/add', methods=['GET', 'POST'])
@login_required
@role_required('admin', 'store_manager')
def add_product():
    """Add new product"""
    if request.method == 'POST':
        try:
            table = get_table(PRODUCTS_TABLE)
            product_id = str(uuid.uuid4())
            
            product = {
                'product_id': product_id,
                'name': request.form.get('name'),
                'category': request.form.get('category'),
                'brand': request.form.get('brand'),
                'price': request.form.get('price'),
                'quantity': int(request.form.get('quantity', 0)),
                'sku': request.form.get('sku'),
                'description': request.form.get('description', ''),
                'created_at': datetime.now().isoformat(),
                'updated_by': session['user_id']
            }
            
            table.put_item(Item=product)
            flash('Product added successfully!', 'success')
            return redirect(url_for('products'))
            
        except ClientError as e:
            flash('Error adding product.', 'danger')
            print(f"DynamoDB Error: {e}")
    
    return render_template('products/add.html')


@app.route('/products/update/<product_id>', methods=['GET', 'POST'])
@login_required
@role_required('admin', 'store_manager')
def update_product(product_id):
    """Update product stock"""
    try:
        table = get_table(PRODUCTS_TABLE)
        
        if request.method == 'POST':
            new_quantity = int(request.form.get('quantity', 0))
            
            table.update_item(
                Key={'product_id': product_id},
                UpdateExpression='SET quantity = :q, updated_at = :t, updated_by = :u',
                ExpressionAttributeValues={
                    ':q': new_quantity,
                    ':t': datetime.now().isoformat(),
                    ':u': session['user_id']
                }
            )
            
            # Check for low stock and send notification
            if new_quantity < LOW_STOCK_THRESHOLD:
                send_low_stock_alert(product_id)
            
            flash('Stock updated successfully!', 'success')
            return redirect(url_for('products'))
        
        # Get product details
        response = table.get_item(Key={'product_id': product_id})
        product = response.get('Item')
        
        if not product:
            flash('Product not found.', 'danger')
            return redirect(url_for('products'))
        
        return render_template('products/update.html', product=product)
        
    except ClientError as e:
        flash('Error updating product.', 'danger')
        print(f"DynamoDB Error: {e}")
        return redirect(url_for('products'))


# ==================== SHIPMENT ROUTES ====================

@app.route('/shipments')
@login_required
def shipments():
    """View all shipments"""
    try:
        table = get_table(SHIPMENTS_TABLE)
        
        if session['role'] == 'supplier':
            shipments = table.scan(
                FilterExpression=Attr('supplier_id').eq(session['user_id'])
            )['Items']
        else:
            shipments = table.scan()['Items']
        
        return render_template('shipments/list.html', shipments=shipments)
    except ClientError as e:
        flash('Error loading shipments.', 'danger')
        return render_template('shipments/list.html', shipments=[])


@app.route('/shipments/request', methods=['GET', 'POST'])
@login_required
@role_required('admin', 'store_manager')
def request_shipment():
    """Create restock request"""
    if request.method == 'POST':
        try:
            # Get suppliers
            users_table = get_table(USERS_TABLE)
            suppliers = users_table.scan(
                FilterExpression=Attr('role').eq('supplier')
            )['Items']
            
            if not suppliers:
                flash('No suppliers available.', 'warning')
                return redirect(url_for('products'))
            
            shipment_id = str(uuid.uuid4())
            supplier = suppliers[0]  # Assign to first available supplier
            
            shipment = {
                'shipment_id': shipment_id,
                'product_id': request.form.get('product_id'),
                'product_name': request.form.get('product_name'),
                'quantity': int(request.form.get('quantity', 0)),
                'supplier_id': supplier['user_id'],
                'supplier_name': supplier['name'],
                'status': 'pending',
                'requested_by': session['user_id'],
                'requested_at': datetime.now().isoformat()
            }
            
            shipments_table = get_table(SHIPMENTS_TABLE)
            shipments_table.put_item(Item=shipment)
            
            # Send SNS notification
            send_restock_request_notification(shipment, supplier['email'])
            
            flash('Restock request sent to supplier!', 'success')
            return redirect(url_for('shipments'))
            
        except ClientError as e:
            flash('Error creating shipment request.', 'danger')
            print(f"DynamoDB Error: {e}")
    
    # Get products for the form
    try:
        products_table = get_table(PRODUCTS_TABLE)
        products = products_table.scan()['Items']
        low_stock = [p for p in products if int(p.get('quantity', 0)) < LOW_STOCK_THRESHOLD]
    except:
        low_stock = []
    
    return render_template('shipments/request.html', products=low_stock)


@app.route('/shipments/update/<shipment_id>', methods=['POST'])
@login_required
@role_required('supplier')
def update_shipment(shipment_id):
    """Update shipment status"""
    try:
        new_status = request.form.get('status')
        tracking_number = request.form.get('tracking_number', '')
        
        table = get_table(SHIPMENTS_TABLE)
        
        update_expr = 'SET #s = :s, updated_at = :t'
        expr_values = {
            ':s': new_status,
            ':t': datetime.now().isoformat()
        }
        
        if tracking_number:
            update_expr += ', tracking_number = :tn'
            expr_values[':tn'] = tracking_number
        
        if new_status == 'shipped':
            update_expr += ', shipped_at = :sa'
            expr_values[':sa'] = datetime.now().isoformat()
        elif new_status == 'delivered':
            update_expr += ', delivered_at = :da'
            expr_values[':da'] = datetime.now().isoformat()
        
        table.update_item(
            Key={'shipment_id': shipment_id},
            UpdateExpression=update_expr,
            ExpressionAttributeNames={'#s': 'status'},
            ExpressionAttributeValues=expr_values
        )
        
        # Send notification for shipped items
        if new_status == 'shipped':
            send_shipment_confirmation(shipment_id)
        
        flash(f'Shipment status updated to {new_status}!', 'success')
        
    except ClientError as e:
        flash('Error updating shipment.', 'danger')
        print(f"DynamoDB Error: {e}")
    
    return redirect(url_for('supplier_dashboard'))


@app.route('/shipments/receive/<shipment_id>', methods=['POST'])
@login_required
@role_required('store_manager')
def receive_shipment(shipment_id):
    """Mark shipment as received and update inventory"""
    try:
        shipments_table = get_table(SHIPMENTS_TABLE)
        products_table = get_table(PRODUCTS_TABLE)
        
        # Get shipment details
        response = shipments_table.get_item(Key={'shipment_id': shipment_id})
        shipment = response.get('Item')
        
        if not shipment:
            flash('Shipment not found.', 'danger')
            return redirect(url_for('manager_dashboard'))
        
        # Update shipment status
        shipments_table.update_item(
            Key={'shipment_id': shipment_id},
            UpdateExpression='SET #s = :s, received_at = :r, received_by = :rb',
            ExpressionAttributeNames={'#s': 'status'},
            ExpressionAttributeValues={
                ':s': 'received',
                ':r': datetime.now().isoformat(),
                ':rb': session['user_id']
            }
        )
        
        # Update product inventory
        product_id = shipment['product_id']
        quantity_received = int(shipment['quantity'])
        
        # Get current quantity
        product_response = products_table.get_item(Key={'product_id': product_id})
        current_quantity = int(product_response.get('Item', {}).get('quantity', 0))
        
        # Update quantity
        products_table.update_item(
            Key={'product_id': product_id},
            UpdateExpression='SET quantity = :q, updated_at = :t',
            ExpressionAttributeValues={
                ':q': current_quantity + quantity_received,
                ':t': datetime.now().isoformat()
            }
        )
        
        flash(f'Shipment received! Inventory updated by {quantity_received} units.', 'success')
        
    except ClientError as e:
        flash('Error receiving shipment.', 'danger')
        print(f"DynamoDB Error: {e}")
    
    return redirect(url_for('manager_dashboard'))


# ==================== ADMIN ROUTES ====================

@app.route('/admin/users')
@login_required
@role_required('admin')
def manage_users():
    """Manage users"""
    try:
        table = get_table(USERS_TABLE)
        users = table.scan()['Items']
        return render_template('admin/users.html', users=users)
    except ClientError as e:
        flash('Error loading users.', 'danger')
        return render_template('admin/users.html', users=[])


@app.route('/admin/users/update/<user_id>', methods=['POST'])
@login_required
@role_required('admin')
def update_user_role(user_id):
    """Update user role"""
    try:
        new_role = request.form.get('role')
        table = get_table(USERS_TABLE)
        
        table.update_item(
            Key={'user_id': user_id},
            UpdateExpression='SET #r = :r, updated_at = :t',
            ExpressionAttributeNames={'#r': 'role'},
            ExpressionAttributeValues={
                ':r': new_role,
                ':t': datetime.now().isoformat()
            }
        )
        
        flash('User role updated successfully!', 'success')
        
    except ClientError as e:
        flash('Error updating user role.', 'danger')
        print(f"DynamoDB Error: {e}")
    
    return redirect(url_for('manage_users'))


@app.route('/admin/export/<data_type>')
@login_required
@role_required('admin')
def export_data(data_type):
    """Export data to CSV"""
    try:
        if data_type == 'products':
            table = get_table(PRODUCTS_TABLE)
            items = table.scan()['Items']
            filename = 'products_export.csv'
            fieldnames = ['product_id', 'name', 'category', 'brand', 'price', 'quantity', 'sku']
        elif data_type == 'shipments':
            table = get_table(SHIPMENTS_TABLE)
            items = table.scan()['Items']
            filename = 'shipments_export.csv'
            fieldnames = ['shipment_id', 'product_name', 'quantity', 'status', 'supplier_name', 'requested_at']
        elif data_type == 'users':
            table = get_table(USERS_TABLE)
            items = table.scan()['Items']
            filename = 'users_export.csv'
            fieldnames = ['user_id', 'name', 'email', 'role', 'status', 'created_at']
        else:
            flash('Invalid export type.', 'danger')
            return redirect(url_for('admin_dashboard'))
        
        # Create CSV
        output = io.StringIO()
        writer = csv.DictWriter(output, fieldnames=fieldnames, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(items)
        
        return Response(
            output.getvalue(),
            mimetype='text/csv',
            headers={'Content-Disposition': f'attachment; filename={filename}'}
        )
        
    except ClientError as e:
        flash('Error exporting data.', 'danger')
        print(f"DynamoDB Error: {e}")
        return redirect(url_for('admin_dashboard'))


# ==================== SNS NOTIFICATION FUNCTIONS ====================

def send_low_stock_alert(product_id):
    """Send low stock notification via SNS"""
    if not LOW_STOCK_TOPIC:
        return
    
    try:
        table = get_table(PRODUCTS_TABLE)
        response = table.get_item(Key={'product_id': product_id})
        product = response.get('Item', {})
        
        message = f"""
        LOW STOCK ALERT - StyleLane Inventory
        
        Product: {product.get('name', 'Unknown')}
        SKU: {product.get('sku', 'N/A')}
        Current Stock: {product.get('quantity', 0)} units
        Category: {product.get('category', 'N/A')}
        
        Please initiate a restock request immediately.
        
        - StyleLane Inventory System
        """
        
        sns.publish(
            TopicArn=LOW_STOCK_TOPIC,
            Subject='Low Stock Alert - StyleLane',
            Message=message
        )
        
    except ClientError as e:
        print(f"SNS Error: {e}")


def send_restock_request_notification(shipment, supplier_email):
    """Send restock request notification via SNS"""
    if not SHIPMENT_TOPIC:
        return
    
    try:
        message = f"""
        NEW RESTOCK REQUEST - StyleLane
        
        Product: {shipment.get('product_name', 'Unknown')}
        Quantity Requested: {shipment.get('quantity', 0)} units
        Request ID: {shipment.get('shipment_id', 'N/A')}
        
        Please log in to your Supplier Dashboard to process this request.
        
        - StyleLane Inventory System
        """
        
        sns.publish(
            TopicArn=SHIPMENT_TOPIC,
            Subject='New Restock Request - StyleLane',
            Message=message
        )
        
    except ClientError as e:
        print(f"SNS Error: {e}")


def send_shipment_confirmation(shipment_id):
    """Send shipment confirmation notification via SNS"""
    if not SHIPMENT_TOPIC:
        return
    
    try:
        table = get_table(SHIPMENTS_TABLE)
        response = table.get_item(Key={'shipment_id': shipment_id})
        shipment = response.get('Item', {})
        
        message = f"""
        SHIPMENT CONFIRMATION - StyleLane
        
        Product: {shipment.get('product_name', 'Unknown')}
        Quantity: {shipment.get('quantity', 0)} units
        Tracking Number: {shipment.get('tracking_number', 'N/A')}
        Status: Shipped
        
        The shipment is on its way!
        
        - StyleLane Inventory System
        """
        
        sns.publish(
            TopicArn=SHIPMENT_TOPIC,
            Subject='Shipment Confirmation - StyleLane',
            Message=message
        )
        
    except ClientError as e:
        print(f"SNS Error: {e}")


# ==================== ERROR HANDLERS ====================

@app.errorhandler(404)
def not_found(e):
    return render_template('errors/404.html'), 404


@app.errorhandler(500)
def server_error(e):
    return render_template('errors/500.html'), 500


# ==================== MAIN ====================

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
